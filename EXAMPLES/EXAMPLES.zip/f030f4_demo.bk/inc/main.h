#ifndef __MAIN_H__
#define __MAIN_H__

#ifdef __cplusplus /* provide compatibility between C and C++ */
  extern "C" {
#endif

#define NO                             0
#define NONE                           NO
#define OFF                            NO
#define YES                            (!NO)
#define ON                             YES

#define HCLK                           8    /* 8 to 68 (MHz) with a step of 4 */

#define SYSTICK_CLOCK_SOURCE           0    /* 0 = HCLK / 8; 1 = HCLK         */
#define SYSTICK_EN                     YES
#define SYSTICK_IRQ_EN                 NO

#include "stm32f030x6.h" /* Include CMSIS header file */

/* Uncomment corresponding line if using the peripheral is intended. */
// #include "pwr.h"
// #include "ob.h"
// #include "tim.h"
// #include "rtc.h"
// #include "wwdg.h"
// #include "iwdg.h"
// #include "i2c.h"
// #include "syscfg.h"
// #include "exti.h"
// #include "adc.h"
// #include "spi.h"
// #include "usart.h"
// #include "dbgmcu.h"
// #include "dma.h"
// #include "crc.h"
// #include "flash.h"

#include "gpio.h"
#include "rcc.h"


__STATIC_FORCEINLINE void init_systick(void);


/* Initialize all the required peripherals */
__STATIC_FORCEINLINE void init(void) {

#if(defined(FLASH_EN) && FLASH_EN)
  init_flash();
#endif

  /* RCC should always be initialized as it is essential peripheral for the functioning of the system. */
  init_rcc();

#if(defined(PWR_EN) && PWR_EN)
  init_pwr();
#endif

#if(defined(OB_EN) && OB_EN)
  init_ob();
#endif

#if(defined(TIM1_EN) && TIM1_EN) || (defined(TIM3_EN) && TIM3_EN) || (defined(TIM14_EN) && TIM14_EN) || (defined(TIM16_EN) && TIM16_EN) || (defined(TIM17_EN) && TIM17_EN)
  init_tim();
#endif

#if(defined(RTC_EN) && RTC_EN)
  init_rtc();
#endif

#if(defined(WWDG_EN) && WWDG_EN)
  init_wwdg();
#endif

#if(defined(IWDG_EN) && IWDG_EN)
  init_iwdg();
#endif

#if(defined(I2C1_EN) && I2C1_EN)
  init_i2c();
#endif

#if(defined(SYSCFG_EN) && SYSCFG_EN)
  init_syscfg();
#endif

#if(defined(EXTI_EN) && EXTI_EN)
  init_exti();
#endif

#if(defined(ADC1_EN) && ADC1_EN)
  init_adc();
#endif

#if(defined(SPI1_EN) && SPI1_EN)
  init_spi();
#endif

#if(defined(USART1_EN) && USART1_EN)
  init_usart();
#endif

#if(defined(DBGMCU_EN) && DBGMCU_EN)
  init_dbgmcu();
#endif

#if(defined(DMA1_EN) && DMA1_EN)
  init_dma();
#endif

#if(defined(CRC_EN) && CRC_EN)
  init_crc();
#endif

  /* GPIO should always be initialized as it is essential peripheral for the functioning of the system. */
  init_gpio();

  /* Perform additional steps after initialization */
  init_systick();

} /* init() */


__STATIC_FORCEINLINE void init_systick(void) {

  /* Initialize SysTick to 1 ms period */

  SysTick->LOAD = HCLK * 1000 / (8 - SYSTICK_CLOCK_SOURCE * 7) - 1;
  SysTick->VAL  = SysTick->LOAD;
  SysTick->CTRL = (
    + SYSTICK_CLOCK_SOURCE * SysTick_CTRL_CLKSOURCE_Msk
    + SYSTICK_IRQ_EN       * SysTick_CTRL_TICKINT_Msk
    + SYSTICK_EN           * SysTick_CTRL_ENABLE_Msk
  );
} /* init_systick() */


__STATIC_FORCEINLINE void idle(void); // {
  /* The body of the main program loop follows here */


//} /* idle() */

#if YES == SYSTICK_IRQ_EN
  #define __SYSTICK_VOLATILE volatile
#else
  #define __SYSTICK_VOLATILE
#endif

#if defined(__GNUC__) && ! defined(__clang__)
  void _close_r(void){} void _close(void){} void _lseek_r(void){} void _lseek(void){} void _read_r(void){} void _read(void){} void _write_r(void){}
#endif

////////////////////////////////////////////////////////////////////////////////////////
//  This code was generated for the stm32f030x6 microcontroller by "stm32cgen" tool.
//                          https://github.com/a5021/stm32codegen                          
//  Arguments used:
//    -s 030f4 -M -D NO 0 NONE NO OFF NO YES (!NO) ON YES "" HCLK "8    /* 8 to 68
//    (MHz) with a step of 4 */" "" SYSTICK_CLOCK_SOURCE "0    /* 0 = HCLK / 8; 1 =
//    HCLK         */" SYSTICK_EN YES SYSTICK_IRQ_EN NO --force-inline --post-init
//    init_systick -F "" -F "__STATIC_FORCEINLINE void init_systick(void) {" -F "" -F
//    "  /* Initialize SysTick to 1 ms period */" -F "" -F "  SysTick->LOAD = HCLK *
//    1000 / (8 - SYSTICK_CLOCK_SOURCE * 7) - 1;" -F "  SysTick->VAL  =
//    SysTick->LOAD;" -F "  SysTick->CTRL = (" -F "    + SYSTICK_CLOCK_SOURCE *
//    SysTick_CTRL_CLKSOURCE_Msk" -F "    + SYSTICK_IRQ_EN       *
//    SysTick_CTRL_TICKINT_Msk" -F "    + SYSTICK_EN           *
//    SysTick_CTRL_ENABLE_Msk" -F "  );" -F "} /* init_systick() */" -F "" -F "" -F
//    "__STATIC_FORCEINLINE void idle(void); // {" -F "  /* The body of the main
//    program loop follows here */" -F "" -F "" -F "//} /* idle() */" -F "" -F "#if
//    YES == SYSTICK_IRQ_EN" -F "  #define __SYSTICK_VOLATILE volatile" -F #else -F "
//    #define __SYSTICK_VOLATILE" -F #endif -F "" -F "#if defined(__GNUC__) && !
//    defined(__clang__)" -F "  void _close_r(void){} void _close(void){} void
//    _lseek_r(void){} void _lseek(void){} void _read_r(void){} void _read(void){}
//    void _write_r(void){}" -F #endif
////////////////////////////////////////////////////////////////////////////////////////


#ifdef __cplusplus
  }
#endif /* __cplusplus */
#endif /* __MAIN_H__ */

